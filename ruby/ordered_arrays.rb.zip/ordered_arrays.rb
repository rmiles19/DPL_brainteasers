# brainteaser. ask user to input a number set (however you want them to)
# return their number list after you have put it in an array
# ask user to request highest, lowest, etc. number from their array.

require "pry"
@user_array = []

#this  method 'number_set_list' asks the user to choose one of the 3 sets I have already
#^ created, puts their choice into their array, and re-displays it for them.
puts "Welcome! Choose your favorite set of numbers:"
  def number_set_list
    puts "1) 1, 3, 5, 7, 9, 11, 13, 15, 17, 19 (ODDBALL)"
    puts "2) 2, 4, 6, 8, 10, 12, 14, 16, 18, 20 (EVEN STEVEN)"
    puts "3) 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 (MATH NERD)"
    puts "4) Exit game, because I am no fun. (PARTY-POOPER)"

    user_input = gets.strip.to_i
    case
      when user_input == 1
        @user_array == [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
        puts @user_array
      when  user_input == 2
        @user_array == [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]
        puts @user_array
      when  user_input == 3
        @user_array == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
        puts @user_array
      when user_input == 4
        exit
      else
        puts "Invalid input! Remember to type 1, 2, 3, or 4 to make your choice. Try again."
        number_set_list
    end
  end

#this method allows the player to request a number from their array
  puts "Lets play a game with the set you chose! Choose one of the following options:"
  puts user_array
    def array_request
      puts "1) Give me the highest number in my number list please" #array.max
      puts "2) Give me the lowest number in my number list please" #array.min
      puts "3) Just give me a random number from my list!" #array.sample
      puts "4) Shuffle up my list!" #array.shuffle
      puts ""

    end



number_set_list
